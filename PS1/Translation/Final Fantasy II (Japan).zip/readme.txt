Use with:

(Redump)
Final Fantasy II (Japan).bin
MD5: 1ae5cf2d9d5258bf89c125e1d5438adf
CRC: 1D028487

----
最终幻想2[简][繁][V1.0]
