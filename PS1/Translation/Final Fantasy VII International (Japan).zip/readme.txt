Use with:

(Redump)
Final Fantasy VII International (Japan) (Disc 1).bin
MD5: d87de4eaed7710a10774854e34c2e277
CRC: A92A0E19

Final Fantasy VII International (Japan) (Disc 2).bin
MD5: 207b1d1a2e2eb4b14be1e0f4b2cb0596
CRC: C9A14FFF

Final Fantasy VII International (Japan) (Disc 3).bin
MD5: 47c41ab5f6db0fe1203edc553c2c5887
CRC: AA2C49E3

----
最终幻想7[简][V1.0]
