Use with:

(Redump)
Rockman 8 - Metal Heroes (Japan).bin
MD5: df7a2a86be8658b1528c265070e3749e
CRC: F476A595

----
洛克人8钢铁英雄们[简][部分汉化][GOROSEGA]
