Use with:

(Redump)
Alundra (Japan).bin
MD5: c889bc7a10d90a8029ba1390577272c0
CRC: 116D11C9

----
阿兰多拉[简][V1.1]
