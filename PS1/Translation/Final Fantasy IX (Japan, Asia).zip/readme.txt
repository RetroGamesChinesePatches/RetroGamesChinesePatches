Use with:

(Redump)
Final Fantasy IX (Japan, Asia) (Disc 1).bin
MD5: e60098f3b04619967be9572fb6c1dfd7
CRC: 5A3EAF73

Final Fantasy IX (Japan, Asia) (Disc 2).bin
MD5: 340c3a490cb879f6a98119655dd2a6b2
CRC: 3C2A4008

Final Fantasy IX (Japan, Asia) (Disc 3).bin
MD5: 93aa9db54bfe447b3dc729b8919c8991
CRC: 5A79D539

Final Fantasy IX (Japan, Asia) (Disc 4).bin
MD5: e75b28ee63a27b975ca590bf30b66393
CRC: EA1D5D5A


----
最终幻想9[简][V2.0]
