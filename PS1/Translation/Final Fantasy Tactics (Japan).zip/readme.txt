Use with:

(Redump)
Final Fantasy Tactics (Japan).bin
MD5: dfca4b82f4a85dc8ad5933892155fd95
CRC: 4C7760F4

----
最终幻想战略版[简]
