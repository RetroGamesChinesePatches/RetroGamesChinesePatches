Use with:

(Redump)
Final Fantasy VIII (Japan, Asia) (Disc 1).bin
MD5: cd2a9d4a92c8cea33b434fd41bbf002c
CRC: 2319B365

Final Fantasy VIII (Japan, Asia) (Disc 2).bin
MD5: 2a9c881fe544f7197341d724f994dc3a
CRC: E830492F

Final Fantasy VIII (Japan, Asia) (Disc 3).bin
MD5: db8ca5e2fd20af5dbaac6c70cf52e1c1
CRC: 148127B6

Final Fantasy VIII (Japan, Asia) (Disc 4).bin
MD5: 12ea9305d975265518188a09ce495a46
CRC: D0A82676

----
最终幻想8[简][v1.0修正第三版]
