Use with:

(Redump)
Daikoukai Jidai II (Japan).bin
MD5: 86227f4b653ba44e54335de53ae75edf
CRC: 613509D7

----
大航海时代2[简][完美汉化版1.01][陈志东]
